<?php 
	/*Update credentials*/
	define('EMAIL', '');
	define('PASS', '');
 ?>